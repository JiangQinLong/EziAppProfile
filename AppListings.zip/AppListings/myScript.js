function collapse(){

 document.getElementsByClassName("collapsible").innerHtml="Text change here"



}

